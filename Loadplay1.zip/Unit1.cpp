//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IdCustomHTTPServer"
#pragma link "IdServerIOHandler"
#pragma link "IdServerIOHandlerSocket"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IdHTTPServer1CommandGet(TIdPeerThread *AThread,
      TIdHTTPRequestInfo *ARequestInfo, TIdHTTPResponseInfo *AResponseInfo)
{

  TStringList * str = new TStringList();
  str->LoadFromFile("c:\\Users\\user\\Documents\\Loadplay1\\1.html");
  AResponseInfo->ContentText = str->Text;

  delete str;






}
//---------------------------------------------------------------------------
void __fastcall TForm1::IdHTTPServer1Exception(TIdPeerThread *AThread,
      Exception *AException)
{
//
}
//---------------------------------------------------------------------------

