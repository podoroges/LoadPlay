//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IdCustomHTTPServer.hpp"
#include <IdBaseComponent.hpp>
#include <IdComponent.hpp>
#include <IdHTTPServer.hpp>
#include <IdTCPServer.hpp>
#include "IdServerIOHandler.hpp"
#include "IdServerIOHandlerSocket.hpp"
#include <IdThreadMgr.hpp>
#include <IdThreadMgrDefault.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TIdHTTPServer *IdHTTPServer1;
        TIdServerIOHandlerSocket *IdServerIOHandlerSocket1;
        TIdThreadMgrDefault *IdThreadMgrDefault1;
        void __fastcall IdHTTPServer1CommandGet(TIdPeerThread *AThread,
          TIdHTTPRequestInfo *ARequestInfo,
          TIdHTTPResponseInfo *AResponseInfo);
        void __fastcall IdHTTPServer1Exception(TIdPeerThread *AThread,
          Exception *AException);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
